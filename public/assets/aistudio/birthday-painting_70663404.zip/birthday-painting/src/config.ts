export const CONFIG = {
  portraitPath: '/portrait.jpg',
  birthdayName: 'Егор',
  birthdayMessage: 'С днём рождения!',
  secondaryMessage: 'Пусть этот год будет таким же красивым, как этот момент.',
  /** Подпись в углу картины. Пустая строка — без подписи. */
  signature: `с любовью, ${new Date().getFullYear()}`,
  /** Полная длительность написания портрета, мс. Этапы делят её пропорционально. */
  paintingDuration: 17000,
  enableSound: true,
  confettiAmount: 120,
  devPlaceholder: true,
  /** Максимальная сторона холста в пикселях. */
  maxImageDimension: 1100,
  particleDprCap: 1.75
} as const;
