import { CONFIG } from '../config';

export function BirthdayMessage({ visible, onReplay }: { visible: boolean; onReplay: () => void }) {
  return (
    <aside className={`note ${visible ? 'is-visible' : ''}`} aria-live="polite" aria-hidden={!visible}>
      <span className="tape" aria-hidden="true" />
      <p className="note-to">{CONFIG.birthdayName},</p>
      <h2>{CONFIG.birthdayMessage}</h2>
      <p className="note-text">{CONFIG.secondaryMessage}</p>
      <button className="text-button replay" onClick={onReplay} tabIndex={visible ? 0 : -1}>Посмотреть ещё раз</button>
    </aside>
  );
}
