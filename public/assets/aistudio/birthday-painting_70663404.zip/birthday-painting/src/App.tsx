import { useCallback, useEffect, useRef, useState } from 'react';
import { CONFIG } from './config';
import type { AppState } from './types';
import { CandleScene } from './components/CandleScene';
import { PaintingScene } from './components/PaintingScene';
import { BirthdayMessage } from './components/BirthdayMessage';
import { Celebration } from './components/Celebration';
import { SoftAudio } from './utils/audio';
import './styles.css';

function App() {
  const [state, setState] = useState<AppState>('INTRO');
  const [muted, setMuted] = useState(!CONFIG.enableSound);
  const [replayKey, setReplayKey] = useState(0);
  const [audio] = useState(() => new SoftAudio());
  const timers = useRef<number[]>([]);
  const later = (fn: () => void, ms: number) => { timers.current.push(window.setTimeout(fn, ms)); };
  const clearTimers = () => { timers.current.forEach(clearTimeout); timers.current = []; };

  useEffect(() => { const id = requestAnimationFrame(() => setState('CANDLE')); return () => cancelAnimationFrame(id); }, []);
  useEffect(() => { audio.setMuted(muted); }, [audio, muted]);
  useEffect(() => clearTimers, []);

  // Звук будится прямо в клике, иначе мобильные браузеры его не пустят.
  const startBlow = useCallback(() => { audio.unlock(); audio.blow(); }, [audio]);
  const blown = useCallback(() => {
    setState('BLOWING_CANDLE');
    later(() => setState('TRANSITION'), 1100);
    later(() => setState('PAINTING'), 1900);
  }, []);
  const finished = useCallback(() => {
    audio.finish();
    setState('FINAL_STROKE');
    later(() => setState('BIRTHDAY_MESSAGE'), 900);
    later(() => setState('CELEBRATION'), 1500);
  }, [audio]);
  const reset = useCallback(() => {
    clearTimers();
    audio.stopBrush();
    setState('INTRO');
    setReplayKey((k) => k + 1);
    requestAnimationFrame(() => setState('CANDLE'));
  }, [audio]);

  const paintingVisible = state === 'PAINTING' || state === 'FINAL_STROKE' || state === 'BIRTHDAY_MESSAGE' || state === 'CELEBRATION';
  const messageVisible = state === 'BIRTHDAY_MESSAGE' || state === 'CELEBRATION';

  return (
    <main className={`app state-${state.toLowerCase()}`} key={replayKey}>
      {!paintingVisible && <CandleScene onStart={startBlow} onBlow={blown} muted={muted} onMute={() => setMuted((v) => !v)} />}
      {paintingVisible && <PaintingScene onFinished={finished} audio={audio} />}
      <BirthdayMessage visible={messageVisible} onReplay={reset} />
      <Celebration active={state === 'CELEBRATION'} />
      <div className="grain" aria-hidden="true" />
    </main>
  );
}

export default App;
